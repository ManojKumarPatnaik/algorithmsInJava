package com.ujjwal_Learning.Games;

public class SpinnyCodeingRound {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

	
}
