package com.ujjwal_Learning.LeetCodeQuestions;

public class Node2 {

	public Node2 node;
	public int hd;
	public Node2 left;
	public Node2 right;
	public Integer data;

	public Node2(Node2 node, int hd, Node2 left, Node2 right, int data) {
		this.node = node;
		this.hd = hd;
		this.left = left;
		this.right = right;
		this.data = data;
	}
}
