package com.ujjwal_Learning.LeetCodeQuestions;

public class Pair {

	TreeNode node;
	int vertical;

	public Pair(TreeNode node, int vertical) {
		this.node = node;
		this.vertical = vertical;
	}

}
