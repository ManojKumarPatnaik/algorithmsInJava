package com.ujjwal_Learning.DP_theory.ZeroOneKnapSackPattern;

public class SubsetSumProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {2,3,8,7,10};
		int sum = 11;
		
		
	}

}
