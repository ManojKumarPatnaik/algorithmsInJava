public class HelloGoodbye {
    public static void main(String[] args) { 
        System.out.println("Hello Kevin and Bob. Goodbye Bob and Kevin.");
         System.out.println("Hello Alejandra and Bahati. Goodbye Bahati and Alejandra.");
    }
}

