package com.bawp.freader

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ReaderApplication: Application() {}