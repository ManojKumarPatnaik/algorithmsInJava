package com.bawp.freader.model

data class ListPrice(
    val amount: Double,
    val currencyCode: String
)