package com.bawp.freader.model

data class SearchInfo(
    val textSnippet: String
)