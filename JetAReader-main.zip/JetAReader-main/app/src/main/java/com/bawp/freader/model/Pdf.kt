package com.bawp.freader.model

data class Pdf(
    val acsTokenLink: String,
    val isAvailable: Boolean
)