package com.bawp.freader.model

data class RetailPrice(
    val amountInMicros: Int,
    val currencyCode: String
)