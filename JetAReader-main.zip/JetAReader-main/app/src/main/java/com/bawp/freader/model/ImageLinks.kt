package com.bawp.freader.model

data class ImageLinks(
    val smallThumbnail: String,
    val thumbnail: String
)