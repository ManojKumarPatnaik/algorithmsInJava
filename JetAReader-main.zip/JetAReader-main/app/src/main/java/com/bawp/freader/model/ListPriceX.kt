package com.bawp.freader.model

data class ListPriceX(
    val amountInMicros: Int,
    val currencyCode: String
)