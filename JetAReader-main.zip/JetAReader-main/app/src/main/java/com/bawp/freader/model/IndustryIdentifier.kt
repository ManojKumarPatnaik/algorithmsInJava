package com.bawp.freader.model

data class IndustryIdentifier(
    val identifier: String,
    val type: String
)