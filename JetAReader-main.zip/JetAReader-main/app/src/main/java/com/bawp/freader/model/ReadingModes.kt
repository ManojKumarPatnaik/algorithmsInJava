package com.bawp.freader.model

data class ReadingModes(
    val image: Boolean,
    val text: Boolean
)