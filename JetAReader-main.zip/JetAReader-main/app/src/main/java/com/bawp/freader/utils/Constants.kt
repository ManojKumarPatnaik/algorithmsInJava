package com.bawp.freader.utils

object Constants {
    //https://www.googleapis.com/books/v1/volumes?q=flutter
    const val BASE_URL = "https://www.googleapis.com/books/v1/"
}