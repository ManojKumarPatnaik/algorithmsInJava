package com.bawp.freader.model

data class Epub(
    val acsTokenLink: String,
    val isAvailable: Boolean
)