package com.bawp.freader.model

data class RetailPriceX(
    val amount: Double,
    val currencyCode: String
)